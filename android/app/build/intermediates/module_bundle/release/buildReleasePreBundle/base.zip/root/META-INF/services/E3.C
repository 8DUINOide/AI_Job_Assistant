F3.b
